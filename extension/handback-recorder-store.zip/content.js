(function(){"use strict";const Z="#2f56d8",ee=`
:host {
  all: initial;
  position: fixed;
  inset: 0;
  z-index: 2147483647;
  pointer-events: none;
  color-scheme: light;
}
* { box-sizing: border-box; margin: 0; padding: 0; }

.layer {
  position: fixed;
  inset: 0;
  font-family: 'Segoe UI', system-ui, -apple-system, sans-serif;
  --cobalt: #2f56d8;
  --cobalt-wash: #eef1fc;
  --glass: rgba(255, 255, 255, 0.9);
  --line: #e6e4dd;
  --ink: #23262e;
  --muted: #6b7078;
  --mono: 'Cascadia Mono', 'Consolas', ui-monospace, monospace;
}

/* Depth comes from the hairline and the paper, not a shadow pile — but the pill
   floats over someone else's app, so it gets the smallest lift that reads. */
.glass {
  background: var(--glass);
  border: 1px solid var(--line);
  box-shadow: 0 2px 10px rgba(35, 38, 46, 0.10);
  backdrop-filter: blur(20px) saturate(130%);
  -webkit-backdrop-filter: blur(20px) saturate(130%);
  color: var(--ink);
}

/* ── live ink + click ripples ──────────────────────────── */
/* .on is "the strokes are on screen"; .capture is "the pointer is mine" — the
   dock's draw toggle flips the second one, so turning drawing off hands the
   page back its clicks without erasing what you already drew. */
canvas.live { position: absolute; inset: 0; width: 100%; height: 100%; display: none; }
canvas.live.on { display: block; }
canvas.live.on.capture { pointer-events: auto; touch-action: none; cursor: crosshair; }

/* ── recording dock ────────────────────────────────────── */
/* Everything you can do to a walkthrough in progress, on the page you're
   walking through. Each button carries its key, so nothing is hidden. */
.dock {
  position: absolute;
  left: 50%;
  bottom: 20px;
  transform: translateX(-50%) translateY(8px);
  display: flex;
  align-items: center;
  gap: 3px;
  padding: 6px 6px 6px 14px;
  border-radius: 999px;
  font-size: 13px;
  white-space: nowrap;
  opacity: 0;
  pointer-events: none;
  transition: opacity .16s ease, transform .16s cubic-bezier(.2,.8,.3,1);
}
.dock.on { opacity: 1; transform: translateX(-50%) translateY(0); pointer-events: auto; }
/* Gets out of the way of whatever it's sitting on, without ever being gone. */
.dock.on.near { opacity: .38; }
.dock.on:hover { opacity: 1; }

.dock-live { display: flex; align-items: center; gap: 8px; }
.dock .dot {
  width: 7px; height: 7px; border-radius: 50%;
  background: var(--cobalt);
  box-shadow: 0 0 0 0 rgba(47,86,216,.5);
  animation: pulse 1.9s ease-out infinite;
}
@keyframes pulse {
  0% { box-shadow: 0 0 0 0 rgba(47,86,216,.45); }
  70% { box-shadow: 0 0 0 8px rgba(47,86,216,0); }
  100% { box-shadow: 0 0 0 0 rgba(47,86,216,0); }
}
.dock .clock {
  font-family: var(--mono);
  font-size: 12px;
  font-variant-numeric: tabular-nums;
  letter-spacing: .01em;
  color: var(--ink);
}
.dock .sep { width: 1px; height: 18px; background: var(--line); margin: 0 5px; }

.dock button {
  font: inherit;
  font-size: 13px;
  display: inline-flex;
  align-items: center;
  gap: 6px;
  min-height: 32px;
  padding: 0 10px;
  color: var(--muted);
  background: transparent;
  border: 1px solid transparent;
  border-radius: 999px;
  cursor: pointer;
  transition: background .12s ease, color .12s ease, border-color .12s ease;
}
.dock button:hover { background: var(--cobalt-wash); color: var(--ink); }

/* The key each label advertises, set as a keycap so it reads as a key and not
   as part of the word. */
.dock .cap {
  font-family: var(--mono);
  font-style: normal;
  font-size: 10px;
  line-height: 1;
  padding: 2px 4px;
  border: 1px solid var(--line);
  border-radius: 4px;
  color: var(--muted);
  background: rgba(35,38,46,.03);
}

/* Armed: the ink owns the pointer. The label says how to get back. */
.dock button.arm {
  background: var(--cobalt-wash);
  border-color: rgba(47,86,216,.28);
  color: var(--cobalt);
}
.dock button.arm .cap { border-color: rgba(47,86,216,.28); color: var(--cobalt); background: transparent; }
/* The one label that swaps — hold the width so the row never shuffles. */
.dock button.draw { min-width: 78px; }
/* Stop is the emphasized one, in ink rather than the accent — cobalt is already
   spoken for by the record dot and the armed key. */
.dock button.stop { background: var(--ink); color: #fff; font-weight: 600; }
.dock button.stop .cap { border-color: rgba(255,255,255,.28); color: rgba(255,255,255,.72); background: transparent; }
.dock button.stop:hover { background: #14161b; color: #fff; }

/* ── draw mode, unmistakably ───────────────────────────── */
/* When the ink owns the pointer the whole viewport says so: a cobalt frame
   around the screen and one small tag naming the way back. The frame is in the
   recording too — which is right, because the drawing is the point. */
.frame {
  position: fixed;
  inset: 0;
  display: none;
  pointer-events: none;
  box-shadow: inset 0 0 0 3px rgba(47, 86, 216, 0.55);
}
.layer.draw .frame { display: block; }
.frame .tag {
  position: absolute;
  top: 10px;
  left: 50%;
  transform: translateX(-50%);
  display: inline-flex;
  align-items: center;
  gap: 7px;
  padding: 5px 12px;
  border-radius: 999px;
  font-size: 12px;
  font-weight: 600;
  color: var(--cobalt);
}
.frame .tag .cap { color: var(--cobalt); border-color: rgba(47,86,216,.35); background: transparent; }

/* A click leaves no trace in a screen recording. This is the trace. */
.ripple {
  position: fixed;
  width: 64px;
  height: 64px;
  margin: -32px 0 0 -32px;
  border: 2px solid var(--cobalt);
  border-radius: 50%;
  pointer-events: none;
  opacity: 0;
  animation: ripple .35s cubic-bezier(.2,.8,.3,1) forwards;
}
@keyframes ripple {
  0% { transform: scale(.44); opacity: .9; }
  100% { transform: scale(1); opacity: 0; }
}
`,te=f=>{const h=document.createElement("template");return h.innerHTML=f.trim(),h.content.firstElementChild};function ne(){const f=document.createElement("div");f.id="handback-root";const h=f.attachShadow({mode:"open"}),y=document.createElement("style");y.textContent=ee,h.append(y);const o=te(`
    <div class="layer">
<!--      <canvas class="live"></canvas>
      <div class="frame"><span class="tag glass">drawing <i class="cap">esc</i> to click</span></div>
      <div class="dock glass">
        <span class="dock-live"><span class="dot"></span><span class="clock">0:00</span></span>
        <span class="sep"></span>
        <button class="draw" data-act="draw"><span class="lbl">draw</span><i class="cap">d</i></button>
        <button data-act="clear"><span class="lbl">clear</span><i class="cap">c</i></button>
        <button class="stop" data-act="stop"><span class="lbl">stop</span><i class="cap">s</i></button>
      </div>-->
    </div>
  `);h.append(o);const s=r=>o.querySelector(r);return{host:f,layer:o,dock:s(".dock"),dockDraw:s(".dock button.draw"),dockDrawLabel:s(".dock button.draw .lbl"),clock:s(".clock"),live:s("canvas.live")}}window.__handbackContent||(window.__handbackContent=!0,oe());function oe(){const f="handback:page-event",h="handback:page-nav";let o=null,s=!1,r=!1,d=[],p=!1,w=!1;const x=3e3,ie=4e3;let E=0,u=null,l=!1,_=0,b=null,k=null;function g(e){try{chrome.runtime.sendMessage(e).catch(()=>{})}catch{}}try{const e=document.createElement("script");e.src=chrome.runtime.getURL("injected.js"),e.onload=()=>e.remove(),(document.head||document.documentElement).appendChild(e)}catch{}window.addEventListener("message",e=>{if(e.source!==window)return;const t=e.data;if(t?.source===h){s&&g(O());return}!t||t.source!==f||s&&chrome.runtime.sendMessage({type:"recording:event",event:{level:t.level,message:t.message,detail:t.detail,ts:t.ts},origin:location.origin}).catch(()=>{})});let N=0,K=null,P,z;window.addEventListener("mousemove",e=>{if(!s)return;const t=Date.now();if(t-N<120)return;N=t;const n=document.elementFromPoint(e.clientX,e.clientY);n!==K&&(K=n,P=n?R(n):void 0,z=n?$(n):void 0),chrome.runtime.sendMessage({type:"recording:pointer",origin:location.origin,sample:{ts:t,x:e.clientX,y:e.clientY,sx:e.screenX,sy:e.screenY,vw:window.innerWidth,vh:window.innerHeight,sw:window.screen.width,sh:window.screen.height,selector:P,text:z}}).catch(()=>{})},{capture:!0,passive:!0});function re(e){const t=e instanceof Element?e:null,n=t?$(t):void 0,i=t?`${R(t)}${n?` "${n}"`:""}`:void 0;return{type:"recording:force",why:"click",origin:location.origin,detail:i}}function O(){const e=`${location.origin}${location.pathname}`;return{type:"recording:force",why:"nav",origin:location.origin,detail:e}}function $(e){return(e.textContent??"").replace(/\s+/g," ").trim().slice(0,80)||void 0}const I=e=>{try{return document.querySelectorAll(e).length===1}catch{return!1}};function R(e){const t=[];let n=e,i=0;for(;n&&n.nodeType===1&&i<5;){const a=n;if(a.id){const c=`#${CSS.escape(a.id)}`;if(I(c)){t.unshift(c);break}}const V=a.getAttribute("data-testid")??a.getAttribute("data-test-id")??a.getAttribute("data-cy");if(V){t.unshift(`[data-testid="${V}"]`);break}let M=a.tagName.toLowerCase();const J=Array.from(a.classList).filter(c=>c.length<28&&!/^(ng-|css-|jsx-|sc-|emotion-)/.test(c)&&!/\d{4,}/.test(c)).slice(0,2);J.length&&(M+=`.${J.map(c=>CSS.escape(c)).join(".")}`);const Q=a.parentElement;if(Q){const c=Array.from(Q.children).filter(we=>we.tagName===a.tagName);c.length>1&&(M+=`:nth-of-type(${c.indexOf(a)+1})`)}if(t.unshift(M),t.length&&I(t.join(" > ")))break;n=a.parentElement,i++}return t.join(" > ")||e.tagName.toLowerCase()}function L(){return o||(o=ne(),document.documentElement.appendChild(o.host),ce(o),he(o),o)}function ae(e){return!!(o&&e.composedPath().includes(o.host))}function C(e){const t=window.devicePixelRatio||1;e.live.width=Math.round(window.innerWidth*t),e.live.height=Math.round(window.innerHeight*t),e.live.getContext("2d")?.setTransform(t,0,0,t,0,0),m(e)}function X(){if(p&&w)return 1;const e=Date.now()-E;return e<=x?1:Math.max(0,1-(e-x)/ie)}function m(e){const t=e.live.getContext("2d");if(t){t.clearRect(0,0,e.live.width,e.live.height),t.globalAlpha=X(),t.lineCap="round",t.lineJoin="round",t.strokeStyle=Z,t.lineWidth=3,t.shadowColor="rgba(255,255,255,.85)",t.shadowBlur=3;for(const n of d)n.points.length<2||(t.beginPath(),n.points.forEach((i,a)=>a?t.lineTo(i.x,i.y):t.moveTo(i.x,i.y)),t.stroke());t.globalAlpha=1}}function D(){if(u=null,!(!o||!d.length)){if(Date.now()-E<=x){u=requestAnimationFrame(D);return}if(X()<=0){d=[],m(o);return}m(o),u=requestAnimationFrame(D)}}function Y(){E=Date.now(),u===null&&(u=requestAnimationFrame(D))}function se(){u!==null&&cancelAnimationFrame(u),u=null}function ce(e){e.live.addEventListener("pointerdown",n=>{r&&(n.preventDefault(),e.live.setPointerCapture(n.pointerId),p=!0,w=!1,d.push({points:[{x:n.clientX,y:n.clientY}]}))}),e.live.addEventListener("pointermove",n=>{!r||!p||(w=!0,d[d.length-1]?.points.push({x:n.clientX,y:n.clientY}),Y(),m(e))});const t=()=>{if(p){if(p=!1,!w){d.pop();return}Y(),g({type:"recording:force",why:"click",origin:location.origin,detail:"ink stroke"})}};e.live.addEventListener("pointerup",t),e.live.addEventListener("pointercancel",t)}function S(){r?A():l&&F()}function F(){const e=L();r=!0,p=!1,e.live.classList.add("on","capture"),C(e),v();try{window.focus()}catch{}}function A(){r&&(r=!1,p=!1,o?.live.classList.remove("capture"),v())}function T(){d=[],p=!1,se(),o&&m(o)}const le=120;function de(e){const t=L();l=!0,_=Date.now(),q(),b=window.setInterval(q,1e3),window.addEventListener("mousemove",j,{capture:!0,passive:!0}),window.addEventListener("keydown",U,!0),window.addEventListener("resize",B),v(),C(t),e&&F()}function pe(){l=!1,A(),T(),b&&window.clearInterval(b),b=null,k=null,window.removeEventListener("mousemove",j,!0),window.removeEventListener("keydown",U,!0),window.removeEventListener("resize",B),v(),o?.dock.classList.remove("near")}function v(){o&&(o.dock.classList.toggle("on",l),o.live.classList.toggle("on",l),o.layer.classList.toggle("draw",l&&r),o.dockDrawLabel.textContent=r?"click":"draw",o.dockDraw.classList.toggle("arm",r),k=null)}function q(){if(!o)return;const e=Math.max(0,Math.round((Date.now()-_)/1e3));o.clock.textContent=`${Math.floor(e/60)}:${String(e%60).padStart(2,"0")}`}function j(e){if(!o||!l)return;if(r){o.dock.classList.remove("near");return}const t=k??=o.dock.getBoundingClientRect(),n=Math.max(t.left-e.clientX,0,e.clientX-t.right),i=Math.max(t.top-e.clientY,0,e.clientY-t.bottom);o.dock.classList.toggle("near",(n>0||i>0)&&Math.hypot(n,i)<le)}function B(){k=null,l&&o&&C(o)}const H={d:S,c:T,s:()=>g({type:"recording:stop"})},ue={KeyD:"d",KeyC:"c",KeyS:"s"};function fe(e){const t=e.composedPath()[0]??e.target;if(!t)return!1;const n=t.tagName;return n==="INPUT"||n==="TEXTAREA"||n==="SELECT"||t.isContentEditable===!0}function U(e){if(e.key==="Escape"){if(!r)return;e.preventDefault(),e.stopPropagation(),A();return}if(!l||e.metaKey||e.ctrlKey||e.altKey||e.shiftKey||e.repeat||fe(e))return;const t=H[e.key.toLowerCase()]??H[ue[e.code]??""];t&&(e.preventDefault(),e.stopPropagation(),t())}function he(e){e.dock.addEventListener("mousedown",t=>t.preventDefault()),e.dock.addEventListener("click",t=>{const n=t.target?.closest("button");if(!n)return;t.preventDefault(),t.stopPropagation();const i=n.dataset.act;i==="draw"?S():i==="clear"?T():i==="stop"&&g({type:"recording:stop"})})}function ge(e,t){const n=L(),i=document.createElement("div");i.className="ripple",i.style.left=`${e}px`,i.style.top=`${t}px`,n.layer.append(i),window.setTimeout(()=>i.remove(),420)}function W(e){!s||r||ae(e)||(ge(e.clientX,e.clientY),g(re(e.target)))}function me(){G(),window.addEventListener("pointerdown",W,{capture:!0,passive:!0})}function G(){window.removeEventListener("pointerdown",W,!0)}chrome.runtime.onMessage.addListener((e,t,n)=>{if(e.type==="ping"){n({ok:!0});return}if(e.type==="recording"){if(s=e.active,e.active){me();const i=e.origin??"";!l&&(!i||i===location.origin)&&(de(e.drawStart===!0),g(O()))}else G(),pe();n({ok:!0});return}e.type==="draw:toggle"&&(S(),n({ok:!0}))})}})();
