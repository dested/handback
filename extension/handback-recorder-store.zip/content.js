(function(){"use strict";const V="#2f56d8",J=`
:host {
  all: initial;
  position: fixed;
  inset: 0;
  z-index: 2147483647;
  pointer-events: none;
  color-scheme: light;
}
* { box-sizing: border-box; margin: 0; padding: 0; }

.layer {
  position: fixed;
  inset: 0;
  font-family: 'Segoe UI', system-ui, -apple-system, sans-serif;
  --cobalt: #2f56d8;
  --cobalt-wash: #eef1fc;
  --glass: rgba(255, 255, 255, 0.9);
  --line: #e6e4dd;
  --ink: #23262e;
  --muted: #6b7078;
  --mono: 'Cascadia Mono', 'Consolas', ui-monospace, monospace;
}

/* Depth comes from the hairline and the paper, not a shadow pile — but the pill
   floats over someone else's app, so it gets the smallest lift that reads. */
.glass {
  background: var(--glass);
  border: 1px solid var(--line);
  box-shadow: 0 2px 10px rgba(35, 38, 46, 0.10);
  backdrop-filter: blur(20px) saturate(130%);
  -webkit-backdrop-filter: blur(20px) saturate(130%);
  color: var(--ink);
}

/* ── live ink + click ripples ──────────────────────────── */
/* .on is "the strokes are on screen"; .capture is "the pointer is mine" — the
   dock's draw toggle flips the second one, so turning drawing off hands the
   page back its clicks without erasing what you already drew. */
canvas.live { position: absolute; inset: 0; width: 100%; height: 100%; display: none; }
canvas.live.on { display: block; }
canvas.live.on.capture { pointer-events: auto; touch-action: none; cursor: crosshair; }

/* ── recording dock ────────────────────────────────────── */
/* Everything you can do to a walkthrough in progress, on the page you're
   walking through. Each button carries its key, so nothing is hidden. */
.dock {
  position: absolute;
  left: 50%;
  bottom: 20px;
  transform: translateX(-50%) translateY(8px);
  display: flex;
  align-items: center;
  gap: 3px;
  padding: 6px 6px 6px 14px;
  border-radius: 999px;
  font-size: 13px;
  white-space: nowrap;
  opacity: 0;
  pointer-events: none;
  transition: opacity .16s ease, transform .16s cubic-bezier(.2,.8,.3,1);
}
.dock.on { opacity: 1; transform: translateX(-50%) translateY(0); pointer-events: auto; }
/* Gets out of the way of whatever it's sitting on, without ever being gone. */
.dock.on.near { opacity: .38; }
.dock.on:hover { opacity: 1; }

.dock-live { display: flex; align-items: center; gap: 8px; }
.dock .dot {
  width: 7px; height: 7px; border-radius: 50%;
  background: var(--cobalt);
  box-shadow: 0 0 0 0 rgba(47,86,216,.5);
  animation: pulse 1.9s ease-out infinite;
}
@keyframes pulse {
  0% { box-shadow: 0 0 0 0 rgba(47,86,216,.45); }
  70% { box-shadow: 0 0 0 8px rgba(47,86,216,0); }
  100% { box-shadow: 0 0 0 0 rgba(47,86,216,0); }
}
.dock .clock {
  font-family: var(--mono);
  font-size: 12px;
  font-variant-numeric: tabular-nums;
  letter-spacing: .01em;
  color: var(--ink);
}
.dock .sep { width: 1px; height: 18px; background: var(--line); margin: 0 5px; }

.dock button {
  font: inherit;
  font-size: 13px;
  display: inline-flex;
  align-items: center;
  gap: 6px;
  min-height: 32px;
  padding: 0 10px;
  color: var(--muted);
  background: transparent;
  border: 1px solid transparent;
  border-radius: 999px;
  cursor: pointer;
  transition: background .12s ease, color .12s ease, border-color .12s ease;
}
.dock button:hover { background: var(--cobalt-wash); color: var(--ink); }

/* The key each label advertises, set as a keycap so it reads as a key and not
   as part of the word. */
.dock .cap {
  font-family: var(--mono);
  font-style: normal;
  font-size: 10px;
  line-height: 1;
  padding: 2px 4px;
  border: 1px solid var(--line);
  border-radius: 4px;
  color: var(--muted);
  background: rgba(35,38,46,.03);
}

/* Armed: the ink owns the pointer. The label says how to get back. */
.dock button.arm {
  background: var(--cobalt-wash);
  border-color: rgba(47,86,216,.28);
  color: var(--cobalt);
}
.dock button.arm .cap { border-color: rgba(47,86,216,.28); color: var(--cobalt); background: transparent; }
/* The one label that swaps — hold the width so the row never shuffles. */
.dock button.draw { min-width: 78px; }
/* Stop is the emphasized one, in ink rather than the accent — cobalt is already
   spoken for by the record dot and the armed key. */
.dock button.stop { background: var(--ink); color: #fff; font-weight: 600; }
.dock button.stop .cap { border-color: rgba(255,255,255,.28); color: rgba(255,255,255,.72); background: transparent; }
.dock button.stop:hover { background: #14161b; color: #fff; }

/* ── draw mode, unmistakably ───────────────────────────── */
/* When the ink owns the pointer the whole viewport says so: a cobalt frame
   around the screen and one small tag naming the way back. The frame is in the
   recording too — which is right, because the drawing is the point. */
.frame {
  position: fixed;
  inset: 0;
  display: none;
  pointer-events: none;
  box-shadow: inset 0 0 0 3px rgba(47, 86, 216, 0.55);
}
.layer.draw .frame { display: block; }
.frame .tag {
  position: absolute;
  top: 10px;
  left: 50%;
  transform: translateX(-50%);
  display: inline-flex;
  align-items: center;
  gap: 7px;
  padding: 5px 12px;
  border-radius: 999px;
  font-size: 12px;
  font-weight: 600;
  color: var(--cobalt);
}
.frame .tag .cap { color: var(--cobalt); border-color: rgba(47,86,216,.35); background: transparent; }

/* A click leaves no trace in a screen recording. This is the trace. */
.ripple {
  position: fixed;
  width: 64px;
  height: 64px;
  margin: -32px 0 0 -32px;
  border: 2px solid var(--cobalt);
  border-radius: 50%;
  pointer-events: none;
  opacity: 0;
  animation: ripple .35s cubic-bezier(.2,.8,.3,1) forwards;
}
@keyframes ripple {
  0% { transform: scale(.44); opacity: .9; }
  100% { transform: scale(1); opacity: 0; }
}
`,Q=f=>{const h=document.createElement("template");return h.innerHTML=f.trim(),h.content.firstElementChild};function Z(){const f=document.createElement("div");f.id="handback-root";const h=f.attachShadow({mode:"open"}),y=document.createElement("style");y.textContent=J,h.append(y);const o=Q(`
    <div class="layer">
      <canvas class="live"></canvas>
      <div class="frame"><span class="tag glass">drawing <i class="cap">esc</i> to click</span></div>
      <div class="dock glass">
        <span class="dock-live"><span class="dot"></span><span class="clock">0:00</span></span>
        <span class="sep"></span>
        <button class="draw" data-act="draw"><span class="lbl">draw</span><i class="cap">d</i></button>
        <button data-act="clear"><span class="lbl">clear</span><i class="cap">c</i></button>
        <button class="stop" data-act="stop"><span class="lbl">stop</span><i class="cap">s</i></button>
      </div>
    </div>
  `);h.append(o);const s=r=>o.querySelector(r);return{host:f,layer:o,dock:s(".dock"),dockDraw:s(".dock button.draw"),dockDrawLabel:s(".dock button.draw .lbl"),clock:s(".clock"),live:s("canvas.live")}}window.__handbackContent||(window.__handbackContent=!0,ee());function ee(){const f="handback:page-event",h="handback:page-nav";let o=null,s=!1,r=!1,d=[],p=!1,w=!1;const x=3e3,te=4e3;let E=0,u=null,l=!1,_=0,b=null,k=null;function g(e){try{chrome.runtime.sendMessage(e).catch(()=>{})}catch{}}try{const e=document.createElement("script");e.src=chrome.runtime.getURL("injected.js"),e.onload=()=>e.remove(),(document.head||document.documentElement).appendChild(e)}catch{}window.addEventListener("message",e=>{if(e.source!==window)return;const t=e.data;if(t?.source===h){s&&chrome.runtime.sendMessage({type:"recording:force",why:"nav",origin:location.origin}).catch(()=>{});return}!t||t.source!==f||s&&chrome.runtime.sendMessage({type:"recording:event",event:{level:t.level,message:t.message,detail:t.detail,ts:t.ts},origin:location.origin}).catch(()=>{})});let K=0,P=null,z,N;window.addEventListener("mousemove",e=>{if(!s)return;const t=Date.now();if(t-K<120)return;K=t;const n=document.elementFromPoint(e.clientX,e.clientY);n!==P&&(P=n,z=n?ne(n):void 0,N=(n?.textContent??"").replace(/\s+/g," ").trim().slice(0,80)||void 0),chrome.runtime.sendMessage({type:"recording:pointer",origin:location.origin,sample:{ts:t,x:e.clientX,y:e.clientY,sx:e.screenX,sy:e.screenY,vw:window.innerWidth,vh:window.innerHeight,sw:window.screen.width,sh:window.screen.height,selector:z,text:N}}).catch(()=>{})},{capture:!0,passive:!0});const I=e=>{try{return document.querySelectorAll(e).length===1}catch{return!1}};function ne(e){const t=[];let n=e,i=0;for(;n&&n.nodeType===1&&i<5;){const a=n;if(a.id){const c=`#${CSS.escape(a.id)}`;if(I(c)){t.unshift(c);break}}const U=a.getAttribute("data-testid")??a.getAttribute("data-test-id")??a.getAttribute("data-cy");if(U){t.unshift(`[data-testid="${U}"]`);break}let T=a.tagName.toLowerCase();const W=Array.from(a.classList).filter(c=>c.length<28&&!/^(ng-|css-|jsx-|sc-|emotion-)/.test(c)&&!/\d{4,}/.test(c)).slice(0,2);W.length&&(T+=`.${W.map(c=>CSS.escape(c)).join(".")}`);const G=a.parentElement;if(G){const c=Array.from(G.children).filter(he=>he.tagName===a.tagName);c.length>1&&(T+=`:nth-of-type(${c.indexOf(a)+1})`)}if(t.unshift(T),t.length&&I(t.join(" > ")))break;n=a.parentElement,i++}return t.join(" > ")||e.tagName.toLowerCase()}function L(){return o||(o=Z(),document.documentElement.appendChild(o.host),re(o),pe(o),o)}function oe(e){return!!(o&&e.composedPath().includes(o.host))}function C(e){const t=window.devicePixelRatio||1;e.live.width=Math.round(window.innerWidth*t),e.live.height=Math.round(window.innerHeight*t),e.live.getContext("2d")?.setTransform(t,0,0,t,0,0),m(e)}function O(){if(p&&w)return 1;const e=Date.now()-E;return e<=x?1:Math.max(0,1-(e-x)/te)}function m(e){const t=e.live.getContext("2d");if(t){t.clearRect(0,0,e.live.width,e.live.height),t.globalAlpha=O(),t.lineCap="round",t.lineJoin="round",t.strokeStyle=V,t.lineWidth=3,t.shadowColor="rgba(255,255,255,.85)",t.shadowBlur=3;for(const n of d)n.points.length<2||(t.beginPath(),n.points.forEach((i,a)=>a?t.lineTo(i.x,i.y):t.moveTo(i.x,i.y)),t.stroke());t.globalAlpha=1}}function D(){if(u=null,!(!o||!d.length)){if(Date.now()-E<=x){u=requestAnimationFrame(D);return}if(O()<=0){d=[],m(o);return}m(o),u=requestAnimationFrame(D)}}function R(){E=Date.now(),u===null&&(u=requestAnimationFrame(D))}function ie(){u!==null&&cancelAnimationFrame(u),u=null}function re(e){e.live.addEventListener("pointerdown",n=>{r&&(n.preventDefault(),e.live.setPointerCapture(n.pointerId),p=!0,w=!1,d.push({points:[{x:n.clientX,y:n.clientY}]}))}),e.live.addEventListener("pointermove",n=>{!r||!p||(w=!0,d[d.length-1]?.points.push({x:n.clientX,y:n.clientY}),R(),m(e))});const t=()=>{if(p){if(p=!1,!w){d.pop();return}R(),g({type:"recording:force",why:"click",origin:location.origin})}};e.live.addEventListener("pointerup",t),e.live.addEventListener("pointercancel",t)}function S(){r?A():l&&X()}function X(){const e=L();r=!0,p=!1,e.live.classList.add("on","capture"),C(e),v();try{window.focus()}catch{}}function A(){r&&(r=!1,p=!1,o?.live.classList.remove("capture"),v())}function M(){d=[],p=!1,ie(),o&&m(o)}const ae=120;function se(e){const t=L();l=!0,_=Date.now(),Y(),b=window.setInterval(Y,1e3),window.addEventListener("mousemove",$,{capture:!0,passive:!0}),window.addEventListener("keydown",j,!0),window.addEventListener("resize",F),v(),C(t),e&&X()}function ce(){l=!1,A(),M(),b&&window.clearInterval(b),b=null,k=null,window.removeEventListener("mousemove",$,!0),window.removeEventListener("keydown",j,!0),window.removeEventListener("resize",F),v(),o?.dock.classList.remove("near")}function v(){o&&(o.dock.classList.toggle("on",l),o.live.classList.toggle("on",l),o.layer.classList.toggle("draw",l&&r),o.dockDrawLabel.textContent=r?"click":"draw",o.dockDraw.classList.toggle("arm",r),k=null)}function Y(){if(!o)return;const e=Math.max(0,Math.round((Date.now()-_)/1e3));o.clock.textContent=`${Math.floor(e/60)}:${String(e%60).padStart(2,"0")}`}function $(e){if(!o||!l)return;if(r){o.dock.classList.remove("near");return}const t=k??=o.dock.getBoundingClientRect(),n=Math.max(t.left-e.clientX,0,e.clientX-t.right),i=Math.max(t.top-e.clientY,0,e.clientY-t.bottom);o.dock.classList.toggle("near",(n>0||i>0)&&Math.hypot(n,i)<ae)}function F(){k=null,l&&o&&C(o)}const q={d:S,c:M,s:()=>g({type:"recording:stop"})},le={KeyD:"d",KeyC:"c",KeyS:"s"};function de(e){const t=e.composedPath()[0]??e.target;if(!t)return!1;const n=t.tagName;return n==="INPUT"||n==="TEXTAREA"||n==="SELECT"||t.isContentEditable===!0}function j(e){if(e.key==="Escape"){if(!r)return;e.preventDefault(),e.stopPropagation(),A();return}if(!l||e.metaKey||e.ctrlKey||e.altKey||e.shiftKey||e.repeat||de(e))return;const t=q[e.key.toLowerCase()]??q[le[e.code]??""];t&&(e.preventDefault(),e.stopPropagation(),t())}function pe(e){e.dock.addEventListener("mousedown",t=>t.preventDefault()),e.dock.addEventListener("click",t=>{const n=t.target?.closest("button");if(!n)return;t.preventDefault(),t.stopPropagation();const i=n.dataset.act;i==="draw"?S():i==="clear"?M():i==="stop"&&g({type:"recording:stop"})})}function ue(e,t){const n=L(),i=document.createElement("div");i.className="ripple",i.style.left=`${e}px`,i.style.top=`${t}px`,n.layer.append(i),window.setTimeout(()=>i.remove(),420)}function B(e){!s||r||oe(e)||(ue(e.clientX,e.clientY),g({type:"recording:force",why:"click",origin:location.origin}))}function fe(){H(),window.addEventListener("pointerdown",B,{capture:!0,passive:!0})}function H(){window.removeEventListener("pointerdown",B,!0)}chrome.runtime.onMessage.addListener((e,t,n)=>{if(e.type==="ping"){n({ok:!0});return}if(e.type==="recording"){if(s=e.active,e.active){fe();const i=e.origin??"";!l&&(!i||i===location.origin)&&(se(e.drawStart===!0),g({type:"recording:force",why:"nav",origin:location.origin}))}else H(),ce();n({ok:!0});return}e.type==="draw:toggle"&&(S(),n({ok:!0}))})}})();
